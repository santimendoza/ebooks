resetPomodoro(): void {
    this.minutes = 24;
    this.seconds = 59;
}
