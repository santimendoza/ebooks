var age: number = 7;
var height: number = 5.6;
