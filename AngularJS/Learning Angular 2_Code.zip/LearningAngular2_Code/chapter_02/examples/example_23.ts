var addAndDouble = (x, y) => {
    var sum = x + y;
    return sum * 2;
};
