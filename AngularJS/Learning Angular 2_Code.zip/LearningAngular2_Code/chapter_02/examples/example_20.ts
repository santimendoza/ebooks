var double = x => x * 2;
