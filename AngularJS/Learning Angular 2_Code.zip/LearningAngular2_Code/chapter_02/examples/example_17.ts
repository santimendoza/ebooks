function greetMe(name: string, greeting: string = 'Hello'): string {
    return greeting + ', ' + name;
}
