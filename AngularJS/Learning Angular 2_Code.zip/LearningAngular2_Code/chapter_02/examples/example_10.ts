enum Brands { Chevrolet, Cadillac, Ford, Buick, Chrysler, Dodge };
var myCarBrandName: string = Brands[1];
