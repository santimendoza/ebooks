var sayHello: (name: string) => string = function(name: string): string{
    return 'Hello, ' + name;
};
