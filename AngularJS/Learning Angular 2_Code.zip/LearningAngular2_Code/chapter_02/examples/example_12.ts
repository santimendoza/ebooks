function sayHello(name: string): string {
    return 'Hello, ' + name;
}
