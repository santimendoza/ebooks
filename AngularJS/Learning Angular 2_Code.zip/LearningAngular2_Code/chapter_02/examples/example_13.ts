var sayHello = function(name: string): string {
    return 'Hello, ' + name;
};
