/// <reference path="greetings/XmasGreeting.ts" />

import XmasGreeting = Greetings.XmasGreeting;
var xmasGreeting = new XmasGreeting();
