var distance: any;

// Assigning different value types is perfectly fine
distance = '1000km';
distance = 1000;

// Allows us to seamlessly combine different types
var distances: any[] = ['1000km', 1000];
