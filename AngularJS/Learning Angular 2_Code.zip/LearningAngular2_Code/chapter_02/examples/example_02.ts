var brand: string = 'Chevrolet';
var message: string = `Today it’s a happy day!
                                  I just bought a new ${brand} car`;
