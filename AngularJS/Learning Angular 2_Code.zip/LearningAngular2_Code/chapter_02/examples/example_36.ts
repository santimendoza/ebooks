@LogOutput
doNothing(input: any): any {
    return input;
}

calc.doNothing(['Angular 2 Essentials', 2016]);
