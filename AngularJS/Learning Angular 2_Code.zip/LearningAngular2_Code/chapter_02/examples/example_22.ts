var reducedArray = [23, 5, 62, 16].reduce((a, b) => a + b, 0);
