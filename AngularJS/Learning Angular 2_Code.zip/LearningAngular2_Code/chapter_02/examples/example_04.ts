var isZeroGreaterThanOne: boolean = false;
