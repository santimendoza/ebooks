import TimerWidgetComponent from './timer-widget.component';

const TIMER_DIRECTIVES: any[] = [
  TimerWidgetComponent
];

export {
  TIMER_DIRECTIVES,
  TimerWidgetComponent
};
