interface Queueable {
  queued: boolean;
}

export default Queueable;
