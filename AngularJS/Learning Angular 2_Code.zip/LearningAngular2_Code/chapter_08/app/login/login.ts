import LoginComponent from './login.component';

export {
  LoginComponent
};
