Introduction
============

This code bundle includes code and Git repositories for Chapter 1
of the book "Mastering Git".


Requirements
============

To follow examples used in the "Mastering Git" book and run the
provided commands, you will need the Git software, preferably version
2.5.0 or later.  Git is an open-source software under GPLv2 license,
and is available for free on every platform (such as Linux, Windows
and MacOS).  All examples use the command-line Git interface, using
the `bash` shell.  Bash has been distributed widely as the default
login shell for Linux distributions and Apple's macOS, and is provided
as a part of 'Git for Windows' installation.

Git is available for free from https://git-scm.com

Chapter 1
---------

To compile and run sample project, development of which is tracked in
the "Chapter 1, Git Basics in Practice", as a demonstration of using
Git for version control, you would need a working C compiler, and the
`make` program.

Chapter 1 focus on providing the practical aspects of the technology,
showing and explaining basic version control operations on an example
of the development of a simple project, and the collaboration between
two developers, Alice and Bob.  This code bundle provides repositories
used by Alice and Bob, respectively in 'alice' and 'bob' directories,
and the central canonical repository, provided in the 'server'
directory ("bare" Git repository).

In real life the development would take place on individual
workstations, while the central repository would be hosted on company
server (visible to all developers).  Sample repositories reflect this
by using https://git.company.com/random for the 'origin' repository
URL.  If you would want to redo steps taken in Chapter 1 using
provided repositories, you would need to replace this URL by the
absolute or the relative path to the 'repositories/server/random.git'
directory in the unpacked bundle.
