Included in this compressed folder is an images folder with images and an index.php file
To function, these files must be kept int his structure on the document root. They are 
called by the file index.html in the Recipe "Responsive image using cookie and javascript"