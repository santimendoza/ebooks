All of these files are html & any styles or scripts are contained in the header. 
The only linking is for the images dir.