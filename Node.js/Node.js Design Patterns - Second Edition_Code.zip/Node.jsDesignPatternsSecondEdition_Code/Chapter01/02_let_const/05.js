"use strict";

const path = require('path');

// .. do stuff with the path module

var path = './some/path'; // this will fail