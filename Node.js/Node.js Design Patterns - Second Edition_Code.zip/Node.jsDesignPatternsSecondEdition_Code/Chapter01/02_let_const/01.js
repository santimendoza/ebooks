"use strict";

if (false) {
  let x = "hello";
}
console.log(x); // ReferenceError: x is not defined
