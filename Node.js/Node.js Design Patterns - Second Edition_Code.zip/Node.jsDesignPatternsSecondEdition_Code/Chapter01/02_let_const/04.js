"use strict";

const x = {};
x.name = 'John'; // This is allowed
//x = null; // This will fail
