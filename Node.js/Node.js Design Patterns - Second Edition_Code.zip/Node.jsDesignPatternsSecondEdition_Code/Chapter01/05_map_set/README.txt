In this folder you can find several examples that show how to use the map and set classes.

To execute them simply run:

  node <filename.js>

(e.g. node 01.js)
