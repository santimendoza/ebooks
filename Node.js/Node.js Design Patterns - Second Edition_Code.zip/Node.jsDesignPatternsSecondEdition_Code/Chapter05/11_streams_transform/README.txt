This example implements a transform stream. To run the example you just need to run:

  node replaceStreamTest
