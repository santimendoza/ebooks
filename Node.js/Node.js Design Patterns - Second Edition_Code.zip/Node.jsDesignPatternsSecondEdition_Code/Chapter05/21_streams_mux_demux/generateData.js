"use strict";

console.log("out1");
console.log("out2");
console.error("err1");
console.log("out3");
console.error("err2");
