This example shows how to merge two streams.

To run the example you have to launch:

  node mergeTar <destinationFile.tar> <sourceFolder1> <sourceFolder2>
