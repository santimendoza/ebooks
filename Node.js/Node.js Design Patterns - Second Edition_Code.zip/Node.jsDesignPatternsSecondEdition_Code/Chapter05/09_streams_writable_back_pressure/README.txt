This example shows how to use a writable stream by building a web server that produces random strings. This example
also manages back pressure.

To run the example you need to:

  npm install
  node entropyServer

than you will be able to point your browser to:

  http://localhost:8080
