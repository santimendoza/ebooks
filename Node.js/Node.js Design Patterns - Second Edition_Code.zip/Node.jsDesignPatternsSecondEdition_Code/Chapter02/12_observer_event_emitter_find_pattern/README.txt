This sample demonstrates how to create and use an EventEmitter.
To run this sample, execute the following command from a terminal:

  node main
