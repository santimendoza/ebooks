This sample demonstrates how to build a middleware infrastructure for ZMQ.

To run the sample you first need to install the ZMQ binaries as explained
at this address:
  http://zeromq.org/intro:get-the-software

Then install all the dependencies:
  npm install

To try the sample, run in two different terminals:
   node server
   
And then:
   node client
