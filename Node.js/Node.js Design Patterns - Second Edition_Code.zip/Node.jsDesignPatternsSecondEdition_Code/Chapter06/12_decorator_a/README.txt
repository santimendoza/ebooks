This example shows how to implement the decorator pattern using prototypes.
To run the example you can simply launch:

  node decorator
