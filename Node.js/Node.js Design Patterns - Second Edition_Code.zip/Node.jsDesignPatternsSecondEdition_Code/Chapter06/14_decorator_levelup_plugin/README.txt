In this example we use the decorator pattern to build a new level up plugin.
Before running the example you need to install the dependencies with

  npm install
  
then you will be able to launch:

  node levelSubscribeTest
