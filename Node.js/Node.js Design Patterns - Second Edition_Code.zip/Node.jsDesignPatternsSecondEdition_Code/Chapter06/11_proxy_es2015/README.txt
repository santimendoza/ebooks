This example illustrates how to create a proxy using ES2015.

To run the example simply execute:

  node test
