This example shows how to create a sequential execution of callbacks.

To execute it launch:

  node test
