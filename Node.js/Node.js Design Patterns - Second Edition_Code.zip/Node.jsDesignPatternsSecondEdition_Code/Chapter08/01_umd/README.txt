This example shows how to implement an UMD module that can be used both in Node.js and in the browser.

To run the example you need to install the dependencies with:

  npm install

then you can run:

  node testServer

to run the code on Node.js, or open the testBrowser.html page in your browser to run it client-side
