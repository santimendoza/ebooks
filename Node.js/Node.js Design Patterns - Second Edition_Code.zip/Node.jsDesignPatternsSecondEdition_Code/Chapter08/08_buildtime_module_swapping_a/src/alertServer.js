"use strict";

module.exports = console.log;
