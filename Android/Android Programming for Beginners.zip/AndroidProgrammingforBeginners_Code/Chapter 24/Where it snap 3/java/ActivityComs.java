package com.gamecodeschool.whereitssnap3;

public interface ActivityComs {

    void onTitlesListItemSelected(int pos);

    void onTagsListItemSelected(String tag);
}

