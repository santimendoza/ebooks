package com.gamecodeschool.whereitssnap4;

public interface ActivityComs {

    void onTitlesListItemSelected(int pos);

    void onTagsListItemSelected(String tag);
}

