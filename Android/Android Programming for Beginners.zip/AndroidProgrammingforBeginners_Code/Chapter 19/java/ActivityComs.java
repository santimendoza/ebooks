package com.gamecodeschool.dualfragments;

public interface ActivityComs {

    void onListItemSelected(int pos);
}

