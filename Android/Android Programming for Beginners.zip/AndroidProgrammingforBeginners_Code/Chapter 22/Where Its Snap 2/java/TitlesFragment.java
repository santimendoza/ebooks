package com.gamecodeschool.whereitssnap2;

import android.app.ListFragment;
import android.os.Bundle;

public class TitlesFragment extends ListFragment {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }


}
