package com.gamecodeschool.whereitssnap2;

import android.app.ListFragment;
import android.os.Bundle;


public class TagsFragment extends ListFragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

}
