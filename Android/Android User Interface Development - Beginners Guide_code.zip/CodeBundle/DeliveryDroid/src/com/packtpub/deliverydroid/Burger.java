package com.packtpub.deliverydroid;

class Burger {
    final String name;
    int count = 0;

    public Burger(final String name) {
        this.name = name;
    }
}
