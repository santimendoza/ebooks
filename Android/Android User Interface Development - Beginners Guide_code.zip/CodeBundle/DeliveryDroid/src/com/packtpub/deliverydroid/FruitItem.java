/*
 * To change this template, choose Tools | Templates
 * && open the template in the editor.
 */
package com.packtpub.deliverydroid;

/**
 * <p>
 * </p><p>
 * Created on 11 Aug 2010
 * </p>
 *
 * @author Jason Morris
 */
class FruitItem {

    final String name;

    final int image;

    FruitItem(String name, int image) {
        this.name = name;
        this.image = image;
    }

}
