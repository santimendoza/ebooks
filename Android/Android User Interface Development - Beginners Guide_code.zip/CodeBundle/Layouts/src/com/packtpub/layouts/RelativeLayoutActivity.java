/*
 * To change this template, choose Tools | Templates
 * && open the template in the editor.
 */
package com.packtpub.layouts;

import android.app.Activity;
import android.os.Bundle;

/**
 * <p>
 * </p><p>
 * Created on 14 Sep 2010
 * </p>
 *
 * @author Jason Morris
 */
public class RelativeLayoutActivity extends Activity {

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.relative_layout);
    }

}
