package practdev;

public class Calculator {
    public void  push(Integer num) {

    }

    public void  op(String op) {

    }

    public Integer  result() {
        return 0;
    }

}
